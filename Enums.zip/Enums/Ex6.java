public class Ex6 {
    enum TipoPagamento {
        CREDITO {
            public double calcularDesconto(double valor) { return valor * 0.02; }
        },
        DEBITO {
            public double calcularDesconto(double valor) { return valor * 0.05; }
        },
        PIX {
            public double calcularDesconto(double valor) { return valor * 0.10; }
        },
        BOLETO {
            public double calcularDesconto(double valor) { return valor * 0.03; }
        };
        
        public abstract double calcularDesconto(double valor);
    }

    public static void main(String[] args) {
        double valor = 1000.0;
        System.out.println("Descontos por tipo de pagamento:");
        for (TipoPagamento tipo : TipoPagamento.values()) {
            System.out.printf("%s: R$ %.2f (desconto de R$ %.2f)%n", 
                tipo.name(), 
                valor - tipo.calcularDesconto(valor), 
                tipo.calcularDesconto(valor));
        }
    }
}