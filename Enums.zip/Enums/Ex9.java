public class Ex9 {
    public static double celsiusParaFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }

    public static double fahrenheitParaCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }

    public static void main(String[] args) {
        System.out.println("30C = " + celsiusParaFahrenheit(30) + "F");
        System.out.println("86F = " + fahrenheitParaCelsius(86) + "C");
    }
}