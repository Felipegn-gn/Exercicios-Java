public class Ex1 {
    enum DiaSemana {
        SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO, DOMINGO;
        
        public boolean ehDiaUtil() {
            return this != SABADO && this != DOMINGO;
        }
    }

    public static void main(String[] args) {
        System.out.println("Dias da semana:");
        for (DiaSemana dia : DiaSemana.values()) {
            System.out.println(dia.name() + ": " + (dia.ehDiaUtil() ? "Dia util" : "Fim de semana"));
        }
    }
}