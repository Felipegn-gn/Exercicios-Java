public class Ex10 {
    public static double soma(double a, double b) {
        return a + b;
    }

    public static double subtrai(double a, double b) {
        return a - b;
    }

    public static double multiplica(double a, double b) {
        return a * b;
    }

    public static double divide(double a, double b) {
        if (b == 0) throw new ArithmeticException("Divisao por zero");
        return a / b;
    }

    public static void main(String[] args) {
        System.out.println("5 + 3 = " + soma(5, 3));
        System.out.println("5 - 3 = " + subtrai(5, 3));
        System.out.println("5 * 3 = " + multiplica(5, 3));
        System.out.println("6 / 3 = " + divide(6, 3));
    }
}