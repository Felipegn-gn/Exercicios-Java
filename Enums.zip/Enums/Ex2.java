public class Ex2 {
    enum Cor {
        VERMELHO(255, 0, 0),
        VERDE(0, 255, 0),
        AZUL(0, 0, 255);
        
        private final int r, g, b;
        
        Cor(int r, int g, int b) {
            this.r = r;
            this.g = g;
            this.b = b;
        }
        
        public String getCodigoRGB() {
            return "RGB(" + r + "," + g + "," + b + ")";
        }
    }

    public static void main(String[] args) {
        System.out.println("Cores RGB:");
        for (Cor cor : Cor.values()) {
            System.out.println(cor.name() + ": " + cor.getCodigoRGB());
        }
    }
}