public class Ex7 {
    enum TipoDocumento {
        CPF {
            public boolean validar(String doc) { return doc != null && doc.matches("\\d{11}"); }
        },
        CNPJ {
            public boolean validar(String doc) { return doc != null && doc.matches("\\d{14}"); }
        };
        
        public abstract boolean validar(String documento);
    }

    public static void main(String[] args) {
        System.out.println("Validacao de documentos:");
        System.out.println("CPF valido? " + TipoDocumento.CPF.validar("12345678901"));
        System.out.println("CNPJ valido? " + TipoDocumento.CNPJ.validar("12345678901234"));
    }
}