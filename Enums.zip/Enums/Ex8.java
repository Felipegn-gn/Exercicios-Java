public class Ex8 {
    enum Naipe {
        COPAS("♥"),
        ESPADAS("♠"),
        OUROS("♦"),
        PAUS("♣");

        private final String simbolo;

        Naipe(String simbolo) {
            this.simbolo = simbolo;
        }

        public String getSimbolo() {
            return simbolo;
        }
    }

    public static void main(String[] args) {
        System.out.println("Naipes do baralho:");
        for (Naipe naipe : Naipe.values()) {
            System.out.println(naipe.name() + ": " + naipe.getSimbolo());
        }
    }
}