public class Ex13 {
    public static boolean validarCPF(String cpf) {
        return cpf != null && cpf.matches("\\d{11}");
    }

    public static void main(String[] args) {
        System.out.println("CPF valido? " + validarCPF("12345678901"));
    }
}