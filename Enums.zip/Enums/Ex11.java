import java.util.Random;

public class Ex11 {
    public static String gerarSenha(int tamanho) {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder senha = new StringBuilder();
        
        for (int i = 0; i < tamanho; i++) {
            senha.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }
        
        return senha.toString();
    }

    public static void main(String[] args) {
        System.out.println("Senha gerada: " + gerarSenha(8));
    }
}