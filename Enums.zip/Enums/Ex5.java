public class Ex5 {
    enum Moeda {
        REAL(1.0),
        DOLAR(5.0),
        EURO(5.5);
        
        private final double cotacao;
        
        Moeda(double cotacao) {
            this.cotacao = cotacao;
        }
        
        public double converterParaReal(double valor) {
            return valor * cotacao;
        }
    }

    public static void main(String[] args) {
        double valor = 100.0;
        System.out.println("Conversao de moedas:");
        for (Moeda moeda : Moeda.values()) {
            System.out.printf("%.2f %s = %.2f BRL%n", valor, moeda.name(), moeda.converterParaReal(valor));
        }
    }
}