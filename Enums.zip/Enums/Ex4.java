public class Ex4 {
    enum StatusPedido {
        PENDENTE {
            public boolean podeCancelar() { return true; }
        },
        PROCESSANDO {
            public boolean podeCancelar() { return true; }
        },
        ENVIADO {
            public boolean podeCancelar() { return false; }
        },
        ENTREGUE {
            public boolean podeCancelar() { return false; }
        };
        
        public abstract boolean podeCancelar();
    }

    public static void main(String[] args) {
        System.out.println("Status de pedido:");
        for (StatusPedido status : StatusPedido.values()) {
            System.out.println(status.name() + " pode cancelar? " + status.podeCancelar());
        }
    }
}