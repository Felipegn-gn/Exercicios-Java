public class Ex3 {
    enum NivelAcesso {
        ADMIN {
            public String getPermissoes() { return "Todas permissoes"; }
        },
        USUARIO {
            public String getPermissoes() { return "Permissoes basicas"; }
        },
        CONVIDADO {
            public String getPermissoes() { return "Apenas leitura"; }
        };
        
        public abstract String getPermissoes();
    }

    public static void main(String[] args) {
        System.out.println("Niveis de acesso:");
        for (NivelAcesso nivel : NivelAcesso.values()) {
            System.out.println(nivel.name() + ": " + nivel.getPermissoes());
        }
    }
}