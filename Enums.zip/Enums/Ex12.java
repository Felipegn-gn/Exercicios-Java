public class Ex12
{
    public static String paraMaiusculas(String texto) {
        return texto.toUpperCase();
    }

    public static int contarVogais(String texto) {
        int count = 0;
        String vogais = "AEIOUaeiou";
        for (char c : texto.toCharArray()) {
            if (vogais.indexOf(c) != -1) count++;
        }
        return count;
    }

    public static String inverterString(String texto) {
        return new StringBuilder(texto).reverse().toString();
    }

    public static void main(String[] args) {
        String teste = "Hello World";
        System.out.println("Original: " + teste);
        System.out.println("Maiusculas: " + paraMaiusculas(teste));
        System.out.println("Vogais: " + contarVogais(teste));
        System.out.println("Invertido: " + inverterString(teste));
    }
}