public class Ex14 {
    public static double areaQuadrado(double lado) {
        return lado * lado;
    }

    public static double areaCirculo(double raio) {
        return Math.PI * raio * raio;
    }

    public static double areaRetangulo(double base, double altura) {
        return base * altura;
    }

    public static void main(String[] args) {
        System.out.println("Area quadrado (5): " + areaQuadrado(5));
        System.out.println("Area circulo (3): " + areaCirculo(3));
        System.out.println("Area retangulo (4x6): " + areaRetangulo(4, 6));
    }
}