// Classe base ContaBancaria
abstract class ContaBancaria {
    protected double saldo;

    public ContaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public double getSaldo() {
        return saldo;
    }

    public abstract void depositar(double valor);

    public abstract void sacar(double valor);

    public void mostrarSaldo() {
        System.out.printf("Saldo atual: R$ %.2f\n", saldo);
    }
}

// Subclasse ContaCorrente
class ContaCorrente extends ContaBancaria {
    private static final double TAXA_SAQUE = 2.50;
    private static final double LIMITE_CHEQUE_ESPECIAL = 1000.00;

    public ContaCorrente(double saldoInicial) {
        super(saldoInicial);
    }

    @Override
    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.printf("Depósito de R$ %.2f realizado na Conta Corrente\n", valor);
        } else {
            System.out.println("Valor de depósito inválido!");
        }
    }

    @Override
    public void sacar(double valor) {
        double valorTotalSaque = valor + TAXA_SAQUE;
        if (valor > 0 && (saldo + LIMITE_CHEQUE_ESPECIAL) >= valorTotalSaque) {
            saldo -= valorTotalSaque;
            System.out.printf("Saque de R$ %.2f realizado (taxa: R$ %.2f)\n", valor, TAXA_SAQUE);
        } else {
            System.out.println("Saldo insuficiente ou valor inválido para saque!");
        }
    }
}

// Subclasse ContaPoupanca
class ContaPoupanca extends ContaBancaria {
    private static final double RENDIMENTO = 0.005; // 0.5% ao mês

    public ContaPoupanca(double saldoInicial) {
        super(saldoInicial);
    }

    @Override
    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            System.out.printf("Depósito de R$ %.2f realizado na Poupança\n", valor);
            aplicarRendimento();
        } else {
            System.out.println("Valor de depósito inválido!");
        }
    }

    @Override
    public void sacar(double valor) {
        if (valor > 0 && saldo >= valor) {
            saldo -= valor;
            System.out.printf("Saque de R$ %.2f realizado da Poupança\n", valor);
        } else {
            System.out.println("Saldo insuficiente ou valor inválido para saque!");
        }
    }

    private void aplicarRendimento() {
        saldo += saldo * RENDIMENTO;
        System.out.printf("Rendimento aplicado: +R$ %.2f\n", saldo * RENDIMENTO);
    }
}

public class Ex4 {
    public static void main(String[] args) {
        // Criando contas
        ContaBancaria corrente = new ContaCorrente(500.00);
        ContaBancaria poupanca = new ContaPoupanca(1000.00);

        // Testando operações na Conta Corrente
        System.out.println("\n--- Operações na Conta Corrente ---");
        corrente.mostrarSaldo();
        corrente.depositar(200.00);
        corrente.mostrarSaldo();
        corrente.sacar(100.00);
        corrente.mostrarSaldo();
        corrente.sacar(600.00); // Testando limite do cheque especial
        corrente.mostrarSaldo();

        // Testando operações na Poupança
        System.out.println("\n--- Operações na Poupança ---");
        poupanca.mostrarSaldo();
        poupanca.depositar(300.00);
        poupanca.mostrarSaldo();
        poupanca.sacar(200.00);
        poupanca.mostrarSaldo();
        poupanca.sacar(2000.00); // Testando saldo insuficiente
        poupanca.mostrarSaldo();
    }
}