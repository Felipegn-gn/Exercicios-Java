interface Notificacao {
    void enviar();
}

class Email implements Notificacao {
    public void enviar() {
        System.out.println("Enviando notificação por e-mail");
    }
}

class SMS implements Notificacao {
    public void enviar() {
        System.out.println("Enviando notificação por SMS");
    }
}

public class Ex14 {
    public static void main(String[] args) {
        Notificacao[] notificacoes = {new Email(), new SMS()};
        
        for (Notificacao n : notificacoes) {
            n.enviar();
        }
    }
}