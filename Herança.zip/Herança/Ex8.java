class Produto {
    String nome;
    double preco;

    Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    void exibirDetalhes() {
        System.out.println("Nome: " + nome + ", Preço: R$" + preco);
    }
}

class Eletronico extends Produto {
    String marca;

    Eletronico(String nome, double preco, String marca) {
        super(nome, preco);
        this.marca = marca;
    }

    @Override
    void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println("Marca: " + marca);
    }
}

class Alimento extends Produto {
    String dataValidade;

    Alimento(String nome, double preco, String dataValidade) {
        super(nome, preco);
        this.dataValidade = dataValidade;
    }

    @Override
    void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println("Data de Validade: " + dataValidade);
    }
}

public class Ex8 {
    public static void main(String[] args) {
        Produto produto = new Produto("Genérico", 10.0);
        Eletronico eletronico = new Eletronico("Smartphone", 1500.0, "Samsung");
        Alimento alimento = new Alimento("Arroz", 25.0, "31/12/2023");

        produto.exibirDetalhes();
        System.out.println();
        eletronico.exibirDetalhes();
        System.out.println();
        alimento.exibirDetalhes();
    }
}