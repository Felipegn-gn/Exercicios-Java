// Classe base Animal
class Animal {
    public void fazerSom() {
        System.out.println("Som genérico de animal");
    }
}

// Subclasse Cachorro
class Cachorro extends Animal {
    @Override
    public void fazerSom() {
        System.out.println("Au au!");
    }
}

// Subclasse Gato
class Gato extends Animal {
    @Override
    public void fazerSom() {
        System.out.println("Miau!");
    }
}

// Subclasse Passaro
class Passaro extends Animal {
    @Override
    public void fazerSom() {
        System.out.println("Piu piu!");
    }
}

public class Ex3 {
    public static void main(String[] args) {
        // Criando um array de animais com tamanho fixo
        Animal[] animais = new Animal[5];
        
        // Preenchendo o array com instâncias de animais
        animais[0] = new Cachorro();
        animais[1] = new Gato();
        animais[2] = new Passaro();
        animais[3] = new Cachorro(); // Outro cachorro
        animais[4] = new Passaro();  // Outro pássaro
        
        // Percorrendo o array e chamando fazerSom() para cada animal
        System.out.println("Sons dos animais:");
        for (int i = 0; i < animais.length; i++) {
            animais[i].fazerSom(); // Polimorfismo em ação!
        }
    }
}