class Tarefa {
    void executar() {
        System.out.println("Executando tarefa genérica");
    }
}

class TarefaEmail extends Tarefa {
    void executar() {
        System.out.println("Enviando e-mail...");
    }
}

class TarefaBackup extends Tarefa {
    void executar() {
        System.out.println("Fazendo backup dos arquivos...");
    }
}

public class Ex13
{
    public static void main(String[] args) {
        Tarefa email = new TarefaEmail();
        Tarefa backup = new TarefaBackup();
        
        email.executar();
        backup.executar();
    }
}