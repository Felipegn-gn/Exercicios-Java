class Funcionario {
    String nome;
    double salarioBase;

    Funcionario(String nome, double salarioBase) {
        this.nome = nome;
        this.salarioBase = salarioBase;
    }

    double calcularPagamento() {
        return salarioBase;
    }
}

class Gerente extends Funcionario {
    double bonus;

    Gerente(String nome, double salarioBase, double bonus) {
        super(nome, salarioBase);
        this.bonus = bonus;
    }

    @Override
    double calcularPagamento() {
        return salarioBase + bonus;
    }
}

class Vendedor extends Funcionario {
    double comissao;
    int vendas;

    Vendedor(String nome, double salarioBase, double comissao, int vendas) {
        super(nome, salarioBase);
        this.comissao = comissao;
        this.vendas = vendas;
    }

    @Override
    double calcularPagamento() {
        return salarioBase + (comissao * vendas);
    }
}

public class Ex10 {
    public static void main(String[] args) {
        Funcionario funcionario = new Funcionario("João", 2000.0);
        Gerente gerente = new Gerente("Maria", 5000.0, 1000.0);
        Vendedor vendedor = new Vendedor("Carlos", 1500.0, 50.0, 10);

        System.out.println("Pagamento do funcionário: R$" + funcionario.calcularPagamento());
        System.out.println("Pagamento do gerente: R$" + gerente.calcularPagamento());
        System.out.println("Pagamento do vendedor: R$" + vendedor.calcularPagamento());
    }
}