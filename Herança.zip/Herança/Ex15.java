class Carta {
    void jogar() {
        System.out.println("Jogando carta genérica");
    }
}

class CartaAtaque extends Carta {
    void jogar() {
        System.out.println("Jogando carta de ataque: Causa 5 de dano!");
    }
}

class CartaDefesa extends Carta {
    void jogar() {
        System.out.println("Jogando carta de defesa: Bloqueia 3 de dano!");
    }
}

public class Ex15 {
    public static void main(String[] args) {
        Carta[] baralho = {new CartaAtaque(), new CartaDefesa(), new CartaAtaque()};
        
        for (Carta c : baralho) {
            c.jogar();
        }
    }
}