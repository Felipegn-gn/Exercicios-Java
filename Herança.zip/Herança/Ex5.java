import java.util.Random;

// Classe base com nome e vida
class Personagem {
    protected String nome;
    protected int vida;

    public Personagem(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public void receberDano(int dano) {
        vida -= dano;
        if (vida < 0) vida = 0;
        System.out.println(nome + " recebeu " + dano + " de dano. Vida restante: " + vida);
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }
}

// Guerreiro é um personagem com ataque de espada
class Guerreiro extends Personagem {
    Random rand = new Random();

    public Guerreiro(String nome) {
        super(nome, 100); // Guerreiro começa com 100 de vida
    }

    public void atacar(Personagem inimigo) {
        int dano = rand.nextInt(10) + 15; // dano aleatório entre 15 e 24
        System.out.println(nome + " ataca com espada!");
        inimigo.receberDano(dano);
    }
}

// Mago é um personagem com ataque mágico
class Mago extends Personagem {
    Random rand = new Random();

    public Mago(String nome) {
        super(nome, 80); // Mago começa com 80 de vida
    }

    public void atacar(Personagem inimigo) {
        int dano = rand.nextInt(10) + 20; // dano aleatório entre 20 e 29
        System.out.println(nome + " lança uma bola de fogo!");
        inimigo.receberDano(dano);
    }
}

// Classe principal que simula a batalha
public class Ex5 {
    public static void main(String[] args) {
        Guerreiro guerreiro = new Guerreiro("Arthas");
        Mago mago = new Mago("Merlin");

        System.out.println("🏁 Batalha começa entre " + guerreiro.getNome() + " e " + mago.getNome() + "!\n");

        // Loop da batalha
        while (guerreiro.estaVivo() && mago.estaVivo()) {
            guerreiro.atacar(mago);
            if (mago.estaVivo()) {
                mago.atacar(guerreiro);
            }

            System.out.println();
           
        }

        System.out.println("Fim da batalha!");
        if (guerreiro.estaVivo()) {
            System.out.println( guerreiro.getNome() + " venceu!");
        } else {
            System.out.println( mago.getNome() + " venceu!");
        }

        // Exibir status final dos personagens
        System.out.println("\n📊 Status final:");
        System.out.println(guerreiro.getNome() + " - Vida: " + guerreiro.getVida());
        System.out.println(mago.getNome() + " - Vida: " + mago.getVida());
    }
}
