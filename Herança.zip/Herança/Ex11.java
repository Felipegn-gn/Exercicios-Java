interface Transporte {
    void mover();
}

class Carro implements Transporte {
    public void mover() {
        System.out.println("Carro andando na estrada");
    }
}

class Bicicleta implements Transporte {
    public void mover() {
        System.out.println("Bicicleta pedalando");
    }
}

class Aviao implements Transporte {
    public void mover() {
        System.out.println("Avião voando");
    }
}

public class Ex11 {
    public static void main(String[] args) {
        Transporte carro = new Carro();
        Transporte bike = new Bicicleta();
        Transporte aviao = new Aviao();
        
        carro.mover();
        bike.mover();
        aviao.mover();
    }
}