class Livro{
    private String titulo;
    private String autor;
    private int anoPublicado;
    
    public Livro(String titulo, String autor, int anoPublicado){
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicado = anoPublicado;
    }
    
    public String getTitulo(){
        return titulo;
    }
    public String getAutor(){
        return autor;
    }
    public int getAno(){
        return anoPublicado;
    }
            
    @Override
    public String toString() {
        return "Livro: " + titulo + " por " + autor + " (" + anoPublicado + ")";
    }    
}

 class LivroFisico extends Livro {
     private int qtd_paginas;
     
     public LivroFisico(String titulo, String autor, int anoPublicado, int qtd_paginas ){
         super(titulo, autor, anoPublicado);
         this.qtd_paginas = qtd_paginas;
         
     }
     
     public int getQtd_paginas(){
         return qtd_paginas;
     }
     
    @Override
    public String toString() {
        return super.toString() + " - " + qtd_paginas + " páginas (Físico)";
    }     
 }
 class Ebook extends Livro {
     private double tamanhoArquivo;
     private String tipo;
     
     public Ebook(String titulo, String autor, int anoPublicado, double tamanhoArquivo, String tipo){
         super(titulo, autor, anoPublicado);
         this.tamanhoArquivo = tamanhoArquivo;
         this.tipo = tipo;
         
     }
     
     public double getTamanho(){
         return tamanhoArquivo;
     }     
     
     public String getTipo(){
         return tipo;
     }
     
     
    @Override
    public String toString() {
        return super.toString() + " - " + tamanhoArquivo + "MB (" + tipo + ")";
    }     
     
 }
public class Ex6
{
	public static void main(String[] args) {
	    LivroFisico livro1 = new LivroFisico("Dom Casmurro", "Machado de Assis", 1899, 256);
        Ebook livro2 = new Ebook("O Alienista", "Machado de Assis", 1882, 2.5, "EPUB");
        LivroFisico livro3 = new LivroFisico("1984", "George Orwell", 1949, 328);
        Ebook livro4 = new Ebook("A Revolução dos Bichos", "George Orwell", 1945, 1.8, "PDF");

        // Exibindo os livros
        System.out.println(livro1);
        System.out.println(livro2);
        System.out.println(livro3);
        System.out.println(livro4);
	
	}
}
