class InstrumentoMusical {
    void tocar() {
        System.out.println("Tocando instrumento");
    }
}

class Violao extends InstrumentoMusical {
    void tocar() {
        System.out.println("Tocando violão: trim trim");
    }
}

class Piano extends InstrumentoMusical {
    void tocar() {
        System.out.println("Tocando piano: plim plim");
    }
}

public class Ex12 {
    public static void main(String[] args) {
        InstrumentoMusical violao = new Violao();
        InstrumentoMusical piano = new Piano();
        
        violao.tocar();
        piano.tocar();
    }
}