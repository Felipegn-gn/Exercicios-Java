class Pessoa {
    String nome;
    int idade;

    Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    void exibirDados() {
        System.out.println("Nome: " + nome + ", Idade: " + idade);
    }
}

class Aluno extends Pessoa {
    String matricula;

    Aluno(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }

    @Override
    void exibirDados() {
        super.exibirDados();
        System.out.println("Matrícula: " + matricula);
    }
}

class Professor extends Pessoa {
    String disciplina;

    Professor(String nome, int idade, String disciplina) {
        super(nome, idade);
        this.disciplina = disciplina;
    }

    @Override
    void exibirDados() {
        super.exibirDados();
        System.out.println("Disciplina: " + disciplina);
    }
}

public class Ex7 {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("João", 30);
        Aluno aluno = new Aluno("Maria", 20, "2023001");
        Professor professor = new Professor("Carlos", 45, "Matemática");

        pessoa.exibirDados();
        System.out.println();
        aluno.exibirDados();
        System.out.println();
        professor.exibirDados();
    }
}